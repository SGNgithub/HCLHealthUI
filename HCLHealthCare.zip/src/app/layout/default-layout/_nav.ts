import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
    badge: {
      color: 'info',
      text: 'NEW'
    }
  },
  {
    title: true,
    name: 'Theme'
  },
  {
    name: 'Master',
    url: '/master',
    iconComponent: { name: 'cil-notes' },
    children: [
      {
        name: 'Staff Creation',
        url: '/master/enquiry',
        icon: 'nav-icon-bullet'
      }
    ]
  },
  {
    name: 'TMS',
    url: '/tms',
    iconComponent: { name: 'cil-notes' },
    children: [
      {
        name: 'Shit Schedular',
        url: '/tms/shit-schedular',
        icon: 'nav-icon-bullet'
      },
      {
        name: 'Attendance',
        url: '/tms/Attendance',
        icon: 'nav-icon-bullet'
      }
    ]
  }
];
