import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { TableColorDirective, TableDirective } from '@coreui/angular';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {
  FormControlDirective,
  FormLabelDirective,
  InputGroupComponent,
  InputGroupTextDirective
} from '@coreui/angular';
import {
  ButtonDirective,
  FormSelectDirective
} from '@coreui/angular';


@Component({
  selector: 'app-attendance',
  standalone: true,
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.scss'],
  imports: [
    InputGroupComponent, InputGroupTextDirective, FormControlDirective, FormLabelDirective,
    ButtonDirective, FormSelectDirective,
    TableDirective, TableColorDirective, CommonModule,FormsModule]
})
export class AttendanceComponent implements OnInit {

  constructor(private http: HttpClient) { }
  tableHeaders: string[] = ['USERID', 'Name', 'EmailID', 'Attendence','Remarks',''];
  tableKeys: string[] = ['EmployeeId', 'EmpName', 'EmailID'];
  tableData = [];
  customDate: string = new Date().toISOString().split('T')[0];

  ngOnInit(): void {
    this.http.get<any>('https://localhost:7256/api/Employee/GetAttendanceList').subscribe((data) => {
      this.tableData = data.responseData;
});
  }

  update(row: any) {
    var remarks = row['Remarks'];
    var status = row['Status'];
    var employeeId = row['EmployeeId']; 
    this.http.post<any>('https://localhost:7256/api/Employee/UpdateAttendanceByUserID',{"userid":employeeId, "status":status, "remarks": remarks}).subscribe((data) => {
      console.log(data);
});
}


GetCalenderDetails(date:string){
  this.http.get<any>(`https://localhost:7256/api/Employee/GetAttendanceListByDate?date=${date}`).subscribe((data) => {
    this.tableData =[];
    this.tableData = data.responseData;
});
}

}
