import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'TMS'
    },
    children: [
      {
        path: 'shit-schedular',
        loadComponent: () => import('./shit-schedular/shit-schedular.component').then(m => m.ShitSchedularComponent),
        data: {
          title: 'shit-schedular'
        }
      },
      {
        path: 'Attendance',
        loadComponent: () => import('./attendance/attendance.component').then(m => m.AttendanceComponent),
        data: {
          title: 'Attendance'
        }
      }
    ]
  }];


