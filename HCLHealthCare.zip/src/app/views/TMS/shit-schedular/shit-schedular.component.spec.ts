import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShitSchedularComponent } from './shit-schedular.component';

describe('ShitSchedularComponent', () => {
  let component: ShitSchedularComponent;
  let fixture: ComponentFixture<ShitSchedularComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShitSchedularComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShitSchedularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
