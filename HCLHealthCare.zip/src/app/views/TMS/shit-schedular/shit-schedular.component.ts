import { Component } from '@angular/core';

@Component({
  selector: 'app-shit-schedular',
  standalone: true,
  imports: [],
  templateUrl: './shit-schedular.component.html',
  styleUrl: './shit-schedular.component.scss'
})
export class ShitSchedularComponent {

}
