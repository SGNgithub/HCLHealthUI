export const ProdUrl={
apiUrl:'https://localhost:44374/api/'
}
