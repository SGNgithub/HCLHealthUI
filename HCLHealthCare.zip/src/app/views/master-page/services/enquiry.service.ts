import { ProdUrl } from './../../Common/Common';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnquiryService {
  handleError:any;

  constructor(private http: HttpClient) {}

  // Create an Enquiry
  createEnquiry(enquiry: any): Observable<any> {
    return this.http.post(ProdUrl.apiUrl+'EnquiryMaster/CreateEnquiryMaster', enquiry)
      .pipe(catchError(this.handleError));
  }

  GetEnquiryDetails(): Observable<any> {
    return this.http.get(ProdUrl.apiUrl+'EnquiryMaster/GetEnquiryMaster')
      .pipe(catchError(this.handleError));
  }

  //Quotation
  GetQuotationDetails(): Observable<any> {
    return this.http.get(ProdUrl.apiUrl+'Quotation/GetQuotationDetails')
      .pipe(catchError(this.handleError));
  }
  GetProductDetails(): Observable<any> {
    return this.http.get(ProdUrl.apiUrl+'Quotation/GetProductDetails')
      .pipe(catchError(this.handleError));
  }
}
