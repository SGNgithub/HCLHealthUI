import { Params } from './../../../../../node_modules/ag-grid-community/dist/types/core/grid.d';
import { EnquiryService } from './../services/enquiry.service';
import { CommonModule, NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RowComponent, ColComponent, TextColorDirective, CardComponent, CardHeaderComponent, CardBodyComponent, FormDirective, FormLabelDirective, FormControlDirective, FormFeedbackComponent, InputGroupComponent, InputGroupTextDirective, FormSelectDirective, FormCheckComponent, FormCheckInputDirective, FormCheckLabelDirective, ButtonDirective, ListGroupDirective, ListGroupItemDirective, TableDirective } from '@coreui/angular';
import { DocsExampleComponent } from '@docs-components/public-api';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';

@Component({
  selector: 'app-enquiry-master',
  standalone: true,
  imports: [RowComponent, ColComponent, TextColorDirective, CardComponent, CardHeaderComponent, CardBodyComponent, DocsExampleComponent, ReactiveFormsModule, FormsModule, FormDirective, FormLabelDirective, FormControlDirective, FormFeedbackComponent, InputGroupComponent, InputGroupTextDirective,
    FormSelectDirective, FormCheckComponent, FormCheckInputDirective,
    FormCheckLabelDirective, ButtonDirective, ListGroupDirective, ListGroupItemDirective, CommonModule, ToastrModule, TableDirective, AgGridAngular],
  providers: [
    EnquiryService,
    ToastrService,
  ],
  templateUrl: './enquiry-master.component.html',
  styleUrl: './enquiry-master.component.scss',
})
export class EnquiryMasterComponent {
  enquiryForm!: FormGroup;
  isAddMode: boolean = false; // Track if we are editing an existing record
  EnquiryDetails: any[] = [];
  // Column Definitions: Defines the columns to be displayed.
  colDefs: ColDef[] = [
    { headerName: "Enquiry Date", field: "CreatedDate", filter: true },
    { headerName: "Customer Name", field: "CustomerName", filter: true },
    { headerName: "Company Name", field: "CompanyName", filter: true },
    { headerName: "Contact No", field: "contactNo", filter: true },
    { headerName: "Email", field: "Email", filter: true },
    { headerName: "Address", field: "Address", filter: true },
    { headerName: "Enquiry Type", field: "EnquiryTypeName", filter: true },
    { headerName: "Enquiry Status", field: "EnquiryStatusName", filter: true },
  ];
  pagination = true;
  paginationPageSize = 500;
  paginationPageSizeSelector = [50, 100, 200, 500, 1000];
  rowClassRules = {
    // apply red to Ford cars
    'rag-green': (params: { data: { EnquiryStatusID: number; }; }) => params.data.EnquiryStatusID === 4,
    'rag-yellow': (params: { data: { EnquiryStatusID: number; }; }) => params.data.EnquiryStatusID === 3,
  };

  constructor(private fb: FormBuilder,
    private enquiryService: EnquiryService,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.initForm();
    this.GetEnquiryDetails()
  }

  GetEnquiryDetails() {
    this.enquiryService.GetEnquiryDetails().subscribe((responsecls: any) => {
      if (responsecls.isSuccess) {
        this.EnquiryDetails = responsecls.responseData
      }
    });
  }

  // Initialize the form controls with default values and validation
  initForm() {
    this.enquiryForm = this.fb.group({
      EnquiryID: [0],
      customerName: ['', Validators.required],
      companyName: [''],
      contactNo: ['', [Validators.required, Validators.pattern('[0-9]{10}')]], // Example: validating 10 digit phone number
      email: ['', [Validators.email]],
      address: [''],
      cityState: ['', Validators.required],
      zipCode: ['', [Validators.required, Validators.pattern('[0-9]{5}')]], // Validating Zip Code as 5 digits
      enquiryType: ['', Validators.required],
      enquiryStatus: ['1', Validators.required],
      squarefeet: ['0'],
      CreatedDate: [''],
      Comments:['']
    });
  }

  // Submit method (Save)
  onSubmit() {
    if (this.enquiryForm.valid) {
      this.saveEnquiry();
    } else {
      this.toastr.error('Validation, Please fill the all valid text', 'Error!');
    }
  }

  // Save method for new entries
  saveEnquiry() {
    this.enquiryService.createEnquiry(this.enquiryForm.value).subscribe((responsecls: any) => {
      if (responsecls.isSuccess) {
        this.toastr.success('Enquiry Created', 'Success!');
        this.EnquiryDetails = responsecls.responseData;
        this.isAddMode = false;
      } else {
        this.toastr.error('Error!', 'Enquiry Failed, Please Contact Admin');
      }
    })
  }

  // Update method for editing existing entries
  updateEnquiry() {
    console.log('Form Updated', this.enquiryForm.value);
    // Implement update logic (API call)
  }

  onCellClicked(Params: any) {
    this.onEdit(Params.data);
  }

  // Edit form method - fill in form with existing data
  onEdit(existingEnquiryData: any) {
    this.isAddMode = true;
    this.enquiryForm.patchValue({
      EnquiryID: existingEnquiryData.EnquiryID,
      customerName: existingEnquiryData.CustomerName,
      companyName: existingEnquiryData.CompanyName,
      contactNo: existingEnquiryData.contactNo,
      email: existingEnquiryData.Email,
      address: existingEnquiryData.Address,
      cityState: existingEnquiryData.CityState,
      zipCode: existingEnquiryData.ZipCode,
      enquiryType: existingEnquiryData.EnquiryType,
      enquiryStatus: existingEnquiryData.EnquiryStatusID,
      squarefeet: existingEnquiryData.EnquiryID,
      CreatedDate: existingEnquiryData.CreatedDate,
      Comments:existingEnquiryData.Comments
    }); // Use patchValue to populate the form
  }

  // Reset form method
  onReset() {
    this.enquiryForm.reset();
  }

  addEnquiry(){
    this.isAddMode = true;
  }

  onBack(){
    this.isAddMode = false;
  }
}
