import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { RowComponent, ColComponent, TextColorDirective, CardComponent, CardHeaderComponent, CardBodyComponent, FormDirective, FormLabelDirective, FormControlDirective, FormFeedbackComponent, InputGroupComponent, InputGroupTextDirective, FormSelectDirective, FormCheckComponent, FormCheckInputDirective, FormCheckLabelDirective, ButtonDirective, ListGroupDirective, ListGroupItemDirective, TableDirective } from '@coreui/angular';
import { DocsExampleComponent } from '@docs-components/public-api';
import { AgGridAngular } from 'ag-grid-angular';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { EnquiryService } from '../services/enquiry.service';
import { ColDef } from 'ag-grid-community';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgSelectModule } from '@ng-select/ng-select';

@Component({
  selector: 'app-quotation',
  standalone: true,
  imports: [RowComponent, ColComponent, TextColorDirective, CardComponent, CardHeaderComponent, CardBodyComponent, DocsExampleComponent, ReactiveFormsModule, FormsModule, FormDirective, FormLabelDirective, FormControlDirective, FormFeedbackComponent, InputGroupComponent, InputGroupTextDirective,
    FormSelectDirective, FormCheckComponent, FormCheckInputDirective,
    FormCheckLabelDirective, ButtonDirective, ListGroupDirective, ListGroupItemDirective, CommonModule, ToastrModule, TableDirective, AgGridAngular, MatDatepickerModule,
    MatNativeDateModule, MatInputModule, MatSelectModule, MatAutocompleteModule, NgSelectModule],
  providers: [
    EnquiryService,
    ToastrService,
  ],
  templateUrl: './quotation.component.html',
  styleUrl: './quotation.component.scss'
})
export class QuotationComponent {
  quotationForm!: FormGroup;
  QuotationDetails: any[] = [];
  ProductDetails: any[] = [];
  IsAddQuotation: boolean = false;
  rowData: any[] = []
  selectedProduct:any;

  //AG-Grid
  colDefs: ColDef[] = [
    { headerName: "Quotation Date", field: "CreatedDate", filter: true },
    { headerName: "Customer Name", field: "CustomerName", filter: true },
    { headerName: "Company Name", field: "CompanyName", filter: true },
    { headerName: "Contact No", field: "contactNo", filter: true },
    { headerName: "Email", field: "Email", filter: true }
  ]
  pagination = true;
  paginationPageSize = 500;
  paginationPageSizeSelector = [50, 100, 200, 500, 1000];

  //Product Details
  columnDefs = [
    { field: 'product', headerName: 'Product', editable: true },
    { field: 'prodDesc', headerName: 'Prod Desc', editable: true },
    { field: 'price', headerName: 'Price', editable: true, valueParser: this.numberParser },
    { field: 'qty', headerName: 'Qty', editable: true, valueParser: this.numberParser },
    {
      field: 'totalPrice',
      headerName: 'Total Price',
      valueGetter: (params: { data: { price: number; qty: number; }; }) => {
        const price = params.data.price || 0;
        const qty = params.data.qty || 0;
        return price * qty;
      }
    }
  ];

  constructor(private fb: FormBuilder,
    private enquiryService: EnquiryService,
    private toastr: ToastrService) {

  }


  ngOnInit(): void {
    this.GetQuotationDetails();
  }

  GetQuotationDetails() {
    this.enquiryService.GetQuotationDetails().subscribe((responsecls: any) => {
      if (responsecls.isSuccess) {
        this.QuotationDetails = responsecls.responseData
      }
    })
  }

  addQuotaton() {
    this.IsAddQuotation = true;
    this.GetProductDetails()
  }

  GetProductDetails() {
    this.enquiryService.GetProductDetails().subscribe((responsecls: any) => {
      if (responsecls.isSuccess) {
        this.ProductDetails = responsecls.responseData
      }
    })
  }

  onCellClicked(Params: any) {
  }

  addBack() {
    this.IsAddQuotation = false;
  }

  initForm() {
    this.quotationForm = this.fb.group({
      QuotationID: [0],
      EnquiryID: [0],
      QuotationDate: [''],
      SubTotal: [''],
      GstValue: [''],
      GrandTotal: [''],
      selectedProduct:['']
    })
  }

  numberParser(params: any) {
    return Number(params.newValue);
  }

  onCellValueChanged(event: any) {
    // Recalculate the total price when 'price' or 'qty' changes
    if (event.colDef.field === 'price' || event.colDef.field === 'qty') {
      const updatedData = this.rowData.map(row => ({
        ...row,
        totalPrice: row.price * row.qty
      }));
      this.rowData = [...updatedData];
    }
  }

  onChangeProduct(params:any){
    debugger
  }
}
