import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Enquiry'
    },
    children: [
      {
        path: 'enquiry',
        loadComponent: () => import('./enquiry-master/enquiry-master.component').then(m => m.EnquiryMasterComponent),
        data: {
          title: 'Enquiry'
        }
      },
      {
        path: 'quotation',
        loadComponent: () => import('./quotation/quotation.component').then(m => m.QuotationComponent),
        data: {
          title: 'Quotation'
        }
      }
    ]
    }
  ]
