import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-NSXR4Z5W.js";
import "./chunk-EF7RJO27.js";
import "./chunk-DVCXGO2A.js";
import "./chunk-V4HSFT2H.js";
import "./chunk-2ZLRKTML.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-5SQEDC4B.js";
import "./chunk-QN5HDKTT.js";
import "./chunk-XPU7EA6D.js";
import "./chunk-MHK6ZZQX.js";
import "./chunk-6WCCERUZ.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
