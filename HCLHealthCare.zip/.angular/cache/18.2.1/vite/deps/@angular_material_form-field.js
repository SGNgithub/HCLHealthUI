import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
} from "./chunk-UF6HVGZF.js";
import "./chunk-32UQVCDQ.js";
import "./chunk-J2QSUN7F.js";
import "./chunk-2YSEVX4Z.js";
import "./chunk-D4FR7AVQ.js";
import "./chunk-NSXR4Z5W.js";
import "./chunk-EF7RJO27.js";
import "./chunk-DVCXGO2A.js";
import "./chunk-V4HSFT2H.js";
import "./chunk-2ZLRKTML.js";
import "./chunk-5SQEDC4B.js";
import "./chunk-QN5HDKTT.js";
import "./chunk-XPU7EA6D.js";
import "./chunk-MHK6ZZQX.js";
import "./chunk-6WCCERUZ.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
//# sourceMappingURL=@angular_material_form-field.js.map
