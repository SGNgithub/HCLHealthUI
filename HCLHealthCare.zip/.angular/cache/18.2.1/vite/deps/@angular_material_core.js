import {
  AnimationCurves,
  AnimationDurations,
  DateAdapter,
  ErrorStateMatcher,
  MATERIAL_SANITY_CHECKS,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_DATE_LOCALE_FACTORY,
  MAT_NATIVE_DATE_FORMATS,
  MAT_OPTGROUP,
  MAT_OPTION_PARENT_COMPONENT,
  MAT_RIPPLE_GLOBAL_OPTIONS,
  MatCommonModule,
  MatLine,
  MatLineModule,
  MatNativeDateModule,
  MatOptgroup,
  MatOption,
  MatOptionModule,
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatPseudoCheckboxModule,
  MatRipple,
  MatRippleLoader,
  MatRippleModule,
  NativeDateAdapter,
  NativeDateModule,
  RippleRef,
  RippleRenderer,
  ShowOnDirtyErrorStateMatcher,
  VERSION,
  _MatOptgroupBase,
  _MatOptionBase,
  _countGroupLabelsBeforeOption,
  _getOptionScrollPosition,
  defaultRippleAnimationConfig,
  mixinColor,
  mixinDisableRipple,
  mixinDisabled,
  mixinErrorState,
  mixinInitialized,
  mixinTabIndex,
  setLines
} from "./chunk-32UQVCDQ.js";
import "./chunk-J2QSUN7F.js";
import "./chunk-2YSEVX4Z.js";
import "./chunk-D4FR7AVQ.js";
import "./chunk-NSXR4Z5W.js";
import "./chunk-EF7RJO27.js";
import "./chunk-DVCXGO2A.js";
import "./chunk-V4HSFT2H.js";
import "./chunk-2ZLRKTML.js";
import "./chunk-5SQEDC4B.js";
import "./chunk-QN5HDKTT.js";
import "./chunk-XPU7EA6D.js";
import "./chunk-MHK6ZZQX.js";
import "./chunk-6WCCERUZ.js";
export {
  AnimationCurves,
  AnimationDurations,
  DateAdapter,
  ErrorStateMatcher,
  MATERIAL_SANITY_CHECKS,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_DATE_LOCALE_FACTORY,
  MAT_NATIVE_DATE_FORMATS,
  MAT_OPTGROUP,
  MAT_OPTION_PARENT_COMPONENT,
  MAT_RIPPLE_GLOBAL_OPTIONS,
  MatCommonModule,
  MatLine,
  MatLineModule,
  MatNativeDateModule,
  MatOptgroup,
  MatOption,
  MatOptionModule,
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatPseudoCheckboxModule,
  MatRipple,
  MatRippleLoader,
  MatRippleModule,
  NativeDateAdapter,
  NativeDateModule,
  RippleRef,
  RippleRenderer,
  ShowOnDirtyErrorStateMatcher,
  VERSION,
  _MatOptgroupBase,
  _MatOptionBase,
  _countGroupLabelsBeforeOption,
  _getOptionScrollPosition,
  defaultRippleAnimationConfig,
  mixinColor,
  mixinDisableRipple,
  mixinDisabled,
  mixinErrorState,
  mixinInitialized,
  mixinTabIndex,
  setLines
};
//# sourceMappingURL=@angular_material_core.js.map
